<?php
define('DIR_ROOT', dirname(__FILE__).'/');
define("OAPI_HOST", "https://oapi.dingtalk.com");

define("CORPID", "");
define("SECRET", "");
define("AGENTID", "");//必填，在创建微应用的时候会分配

