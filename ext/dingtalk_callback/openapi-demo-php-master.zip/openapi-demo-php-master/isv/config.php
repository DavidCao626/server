<?php
define('DIR_ROOT', dirname(__FILE__).'/');
define("OAPI_HOST", "https://oapi.dingtalk.com");
//Suite
define("CREATE_SUITE_KEY", "suite4xxxxxxxxxxxxxxx");
define("SUITE_KEY", "");
define("SUITE_SECRET", "");
define("TOKEN", "");
define("APPID", "");
define("ENCODING_AES_KEY", "");
